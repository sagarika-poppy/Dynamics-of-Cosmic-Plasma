def const_B(x, y, z, t):

    # Constant B field along z-axis

    BPx = 0.0*1e-10
    BPy = 0.0*1e-10
    BPz = 3.0*1e-10 #[uG] micro Gaus; 5uG in this example. it was 3

    EPx = 0.0
    EPy = 0.0
    EPz = 0.0

    return BPx, BPy, BPz, EPx, EPy, EPz

def const_EB(x, y, z, t):

    # Constant B and E field, 
    # Bz, Ex = Ey, Ez = 0

    BPx = 0.0*1e-10
    BPy = 0.0*1e-10
    BPz = 5.0*1e-10      #it was 3.0 in the original file

    EPx = BPz*1e4
    EPy = BPz*1e4
    EPz = 0.0

    return BPx, BPy, BPz, EPx, EPy, EPz

# define your own field here
# For sum 2

def const_B2(x, y, z, t):

    # Constant B field along z-axis
    B_0 = 1.0     #in Gauss
    A = 1.0       #1 tesla per meter is equal to 100 gauss per centimeter.
    BPx = 0.0*1e-10
    BPy = 0.0*1e-10
    BPz = (A*x + B_0)  

    EPx = 0.0
    EPy = 0.0
    EPz = 0.0

    return BPx, BPy, BPz, EPx, EPy, EPz

def const_B3(x, y, z, t):

    # Constant B field along z-axis
    
    A = 0.1      #0.1 tesla per meter is equal to 10 gauss per centimeter.
    BPx = A*z     #A*z*1e-10  #0.0*1e-10
    BPy = 0.0*1e-10
    BPz = (1.0+A*x) #*1e-10 #(1.0+A*x)*1e-10 
    
    

    EPx = 0.0
    EPy = 0.0
    EPz = 0.0

    return BPx, BPy, BPz, EPx, EPy, EPz