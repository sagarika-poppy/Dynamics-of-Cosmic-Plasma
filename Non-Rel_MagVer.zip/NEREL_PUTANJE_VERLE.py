# Based on V. Zekovic & B. Arbutina, Nucl. Part. Phys. Proc. 297-299, 53-57 (2018) but with different numerical algorithm
# Magnetic Verlet


import numpy as np
import matplotlib.pyplot as plt
import PVREDNOSTI, IZLAZ, DEFPOLJA # Input files (PVREDNOSTI: initial conditions are there; IZLAZ: output to be shown in graph is there; DEFPOLJA: field definitions are there)

#############################
# Input parameters
#############################

N = 1 # we use only one particle

T_sim = 3000.0 # simulation duration [s]
dt = 0.1 # time step
T_smp = 5.0 # times step for graphical representation

##########################
# definitions of variables
##########################

l = 0
q = np.zeros(N)
m = np.zeros(N)
x = np.zeros(N)
y = np.zeros(N)
z = np.zeros(N)
vx = np.zeros(N)
vy = np.zeros(N)
vz = np.zeros(N)
EPx = 0.0
EPy = 0.0
EPz = 0.0
BPx = 0.0
BPy = 0.0
BPz = 0.0   
pomx = np.zeros(N)
pomy = np.zeros(N)
pomz = np.zeros(N)

#################
# initialization
#################

t = 0.0
 
q, m, x, y, z, vx, vy, vz = PVREDNOSTI.puslovi(N, np)

BPx, BPy, BPz, EPx, EPy, EPz = DEFPOLJA.const_B(x, y, z, t)

fig, sp1, sp2 = IZLAZ.init_plots(plt)

###############
# Main loop
###############
# See
# https://aapt.scitation.org/doi/10.1119/10.0001876
# https://arxiv.org/abs/2008.11810
# https://www.compadre.org/PICUP/resources/Numerical-Integration/

#kinetickainit = m*0.5*(vx**2.0 + vy**2.0 + vz**2.0)

while t < (T_sim - dt):
	
	t = t + dt	
	
	pomx = vx + ((q*dt*0.5/m)*(EPx + (vy*BPz) - (BPy*vz)))
	pomy = vy + ((q*dt*0.5/m)*(EPy + (vz*BPx) - (BPz*vx)))
	pomz = vz + ((q*dt*0.5/m)*(EPz + (vx*BPy) - (BPx*vy)))

	x = x + (pomx*dt)
	y = y + (pomy*dt)
	z = z + (pomz*dt)

	BPx, BPy, BPz, EPx, EPy, EPz = DEFPOLJA.const_B(x, y, z, t)

	pomx = pomx + ((q*dt*0.5/m)*EPx)
	pomy = pomy + ((q*dt*0.5/m)*EPy)
	pomz = pomz + ((q*dt*0.5/m)*EPz)
	
	vx = ((1.0 + (((q*dt*0.5/m)**2.0)*(BPx**2.0 + BPy**2.0 + BPz**2.0)))**(-1.0))*(pomx + ((q*dt*0.5/m)*(pomy*BPz - pomz*BPy)) + (((q*dt*0.5/m)**2.0)*BPx*(pomx*BPx + pomy*BPy + pomz*BPz)))

	vy = ((1.0 + (((q*dt*0.5/m)**2.0)*(BPx**2.0 + BPy**2.0 + BPz**2.0)))**(-1.0))*(pomy + ((q*dt*0.5/m)*(pomz*BPx - pomx*BPz)) + (((q*dt*0.5/m)**2.0)*BPy*(pomx*BPx + pomy*BPy + pomz*BPz))) 

	vz = ((1.0 + (((q*dt*0.5/m)**2.0)*(BPx**2.0 + BPy**2.0 + BPz**2.0)))**(-1.0))*(pomz + ((q*dt*0.5/m)*(pomx*BPy - pomy*BPx)) + (((q*dt*0.5/m)**2.0)*BPz*(pomx*BPx + pomy*BPy + pomz*BPz)))


	###################################
	# show in graph
	###################################

	l += 1
	
	if l*dt >= T_smp:

		l = 0.0
		IZLAZ.write_plots(sp1, sp2, plt, x, y, z, t, T_sim) # show in real time

#kinetickafin = m*0.5*(vx**2.0 + vy**2.0 + vz**2.0)

#print (kinetickainit - kinetickafin)/kinetickainit
