###########################
# Initial conditions for electrons
###########################

def puslovi_ele(N, np):

    import random

    ########################################
    # input data
    ########################################

    m_e = 9.10938356e-31 # electron mass [kg]
    m_p = 1.6726219e-27 # proton mass [kg] 
    qelem = -1.0*1.6021766210e-19 #elementary charge [C] of proton
    c = 299792458.0 # speed of light [m/s]
    vini = 0.01*c # non-relativistic velocities -- initial velocities in range (-vini, vini)

    q = np.zeros(N)
    m = np.zeros(N)
    x = np.zeros(N)
    y = np.zeros(N)
    z = np.zeros(N)
    vx = np.zeros(N)
    vy = np.zeros(N)
    vz = np.zeros(N)

    for i in range(0,N):
        
        q[i]= qelem #electron here
        m[i] = m_e #mass of electron
        x[i] = 0.0 
        y[i] = 0.0 
        z[i] = 0.0
        vx[i] = 0.0
        vy[i] = (random.random() - 0.5)*vini
        vz[i] = (random.random() - 0.5)*vini

    return q, m, x, y, z, vx, vy, vz



###########################
# Initial conditions for proton
###########################


def puslovi_prot(N, np):

    import random

    ########################################
    # input data
    ########################################

    m_e = 9.10938356e-31 # electron mass [kg]
    m_p = 1.6726219e-27 # proton mass [kg] 
    qelem = 1.6021766210e-19 #elementary charge [C] of proton
    c = 299792458.0 # speed of light [m/s]
    vini = 0.01*c # non-relativistic velocities -- initial velocities in range (-vini, vini)

    q = np.zeros(N)
    m = np.zeros(N)
    x = np.zeros(N)
    y = np.zeros(N)
    z = np.zeros(N)
    vx = np.zeros(N)
    vy = np.zeros(N)
    vz = np.zeros(N)

    for i in range(0,N):
        
        q[i]= qelem #proton here
        m[i] = m_p #mass of proton
        x[i] = 0.0 
        y[i] = 0.0 
        z[i] = 0.0
        vx[i] = 0.0
        vy[i] = (random.random() - 0.5)*vini
        vz[i] = (random.random() - 0.5)*vini

    return q, m, x, y, z, vx, vy, vz

###########################
# Initial conditions for alpha particle
###########################



def puslovi_alp(N, np):

    import random

    ########################################
    # input data
    ########################################

    m_e = 9.10938356e-31 # electron mass [kg]
    m_p = 1.6726219e-27 # proton mass [kg] 
    qelem = 1.6021766210e-19 #elementary charge [C] of proton
    c = 299792458.0 # speed of light [m/s]
    vini = 0.01*c # non-relativistic velocities -- initial velocities in range (-vini, vini)

    q = np.zeros(N)
    m = np.zeros(N)
    x = np.zeros(N)
    y = np.zeros(N)
    z = np.zeros(N)
    vx = np.zeros(N)
    vy = np.zeros(N)
    vz = np.zeros(N)

    for i in range(0,N):
        
        q[i]= 2.0*qelem  # alpha here
        m[i] = 4.0*m_p 
        x[i] = 0.0 
        y[i] = 0.0 
        z[i] = 0.0
        vx[i] = 0.0
        vy[i] = (random.random() - 0.5)*vini
        vz[i] = (random.random() - 0.5)*vini

    return q, m, x, y, z, vx, vy, vz


def puslovi_2(N, np):

    import random

    ########################################
    # input data
    ########################################

    #m_e = 9.10938356e-31 # electron mass [kg]
    #m_p = 1.6726219e-27 # proton mass [kg]
    m = 1.0   # in kg
    #qelem = -1*1.6021766210e-19 # elementary charge [C]
    
    c = 299792458.0 # speed of light [m/s]
    vini = 0.01*c # non-relativistic velocities -- initial velocities in range (-vini, vini)

    q = np.zeros(N)
    m = np.zeros(N)
    x = np.zeros(N)
    y = np.zeros(N)
    z = np.zeros(N)
    vx = np.zeros(N)
    vy = np.zeros(N)
    vz = np.zeros(N)

    for i in range(0,N):

        q[i] = 1.0     # in C
        m[i] = 1.0 #m 
        x[i] = 0.0 
        y[i] = 0.0 
        z[i] = 0.0
        vx[i] = 0.0
        vy[i] = 1.0
        vz[i] = 0.0
    return q, m, x, y, z, vx, vy, vz


def puslovi_3(N, np):

    import random

    ########################################
    # input data
    ########################################

    #m_e = 9.10938356e-31 # electron mass [kg]
    #m_p = 1.6726219e-27 # proton mass [kg]
    m = 1.0   # in kg
    #qelem = -1*1.6021766210e-19 # elementary charge [C]
    
    c = 299792458.0 # speed of light [m/s]
    vini = 0.01*c # non-relativistic velocities -- initial velocities in range (-vini, vini)

    q = np.zeros(N)
    m = np.zeros(N)
    x = np.zeros(N)
    y = np.zeros(N)
    z = np.zeros(N)
    vx = np.zeros(N)
    vy = np.zeros(N)
    vz = np.zeros(N)

    for i in range(0,N):

        q[i] = 1.0     # in C
        m[i] = 1.0
        x[i] = 0.0 
        y[i] = 0.0 
        z[i] = 0.0
        vx[i] = 0.0
        vy[i] = 1.0
        vz[i] = 1.0
    return q, m, x, y, z, vx, vy, vz
