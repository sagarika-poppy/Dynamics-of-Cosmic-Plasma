##########################################################
# output representation
##########################################################

def set_plot_axes():
	
	global sp1, sp2
	sp1.set(adjustable='box', aspect='equal')
	sp2.set(adjustable='box', aspect='equal')
	sp1.set_xlabel('X')
	sp1.set_ylabel('Y')
	sp2.set_xlabel('X')
	sp2.set_ylabel('Z')
	sp1.set_xlim([-10, 10]) #([-70, 70])
	sp1.set_ylim([-10, 10])
	sp2.set_xlim([-10, 10])
	sp2.set_ylim([-10, 10])

##################################################################
# init
##################################################################

def init_plots(plt):
	
	global sp1, sp2
	fig, (sp1, sp2) = plt.subplots(1, 2, figsize = (20, 10))
	set_plot_axes()
	return fig, sp1, sp2

###############################################################
# show
###############################################################

def write_plots(sp1, sp2, plt, x, y, z, t, T_sim):
	
	d = 6378137.0
	s = "T = " + "%7.1f" % float(t) + " of" + "%7.1f" % float(T_sim) + " [s]"
	sp1.set_title(s)
	sp1.plot(x/d, y/d, 'b.', markersize=2)
	sp2.plot(x/d, z/d, 'r.', markersize=2)
	plt.pause(0.00001)
#########################################################################
    
def set_plot_axes2():
	
	global sp12, sp22
	sp12.set(adjustable='box', aspect='equal')
	sp22.set(adjustable='box', aspect='equal')
	sp12.set_xlabel('X')
	sp12.set_ylabel('Y')
	sp22.set_xlabel('X')
	sp22.set_ylabel('Z')
	sp12.set_xlim([-10, 10])
	sp12.set_ylim([-10, 10])
	sp22.set_xlim([-10, 10])
	sp22.set_ylim([-10, 10])
    

def init_plots2(plt):
	
	global sp12, sp22
	fig, (sp12, sp22) = plt.subplots(1, 2, figsize = (20, 10))
	set_plot_axes2()
	return fig, sp12, sp22
    
def write_plots2(sp12, sp22, plt, x, y, z, t, T_sim):
	
	d = 6378137.0
	s = "T = " + "%7.1f" % float(t) + " of" + "%7.1f" % float(T_sim) + " [s]"
	sp12.set_title(s)
	sp12.plot(x/d, y/d, 'b.', markersize=2)
	sp22.plot(x/d, z/d, 'r.', markersize=2)
	plt.pause(0.00001)