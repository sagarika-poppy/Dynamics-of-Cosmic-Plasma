###########################
# initial conditions
###########################

def puslovi(N, np):
	
	import random
	
	########################################
	# input
	########################################

	m_e = 9.10938356e-31 # electron mass [kg]
	m_p = 1.6726219e-27 # proton mass [kg]
	qelem = 1.6021766210e-19 # elem. charge [C]
	c = 299792458.0 #speed of light [m/s]

	q = np.zeros(N)
	m = np.zeros(N)
	x = np.zeros(N)
	y = np.zeros(N)
	z = np.zeros(N)
	vx = np.zeros(N)
	vy = np.zeros(N)
	vz = np.zeros(N)
	
	for i in range(0,N):

		q[i] = 1.0*qelem
		m[i] = 1.0*m_p 
		x[i] = 2.5*6378137.0 #4.0*6378137.0 CHANGE APPROPRIATELY 2.5 earth radius. earth radius =6.71kms
		y[i] = 0.0
		z[i] = 0.0
		vx[i] = 0.0
		vy[i] = 0.145*0.5*c #0.616*0.5*c #0.145*0.5*c
		vz[i] = 0.145*0.866*c #0.616*0.866*c #0.145*0.866*c
	return q, m, x, y, z, vx, vy, vz


def puslovi2(N, np):
	
	import random
	
	########################################
	# input
	########################################

	m_e = 9.10938356e-31 # electron mass [kg]
	m_p = 1.6726219e-27 # proton mass [kg]
	qelem = 1.6021766210e-19 # elem. charge [C]
	c = 299792458.0 #speed of light [m/s]

	q = np.zeros(N)
	m = np.zeros(N)
	x = np.zeros(N)
	y = np.zeros(N)
	z = np.zeros(N)
	vx = np.zeros(N)
	vy = np.zeros(N)
	vz = np.zeros(N)
	
	for i in range(0,N):

		q[i] = 1.0*qelem
		m[i] = 1.0*m_p 
		x[i] = 4.0*6378137.0 #CHANGE APPROPRIATELY 2.5 earth radius. earth radius =6.71kms
		y[i] = 0.0
		z[i] = 0.0
		vx[i] = 0.0
		vy[i] = 0.616*0.5*c #0.145*0.5*c
		vz[i] = 0.616*0.866*c #0.145*0.866*c
	return q, m, x, y, z, vx, vy, vz
